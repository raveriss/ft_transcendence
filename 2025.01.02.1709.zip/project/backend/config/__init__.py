"""
Django configuration package.
"""