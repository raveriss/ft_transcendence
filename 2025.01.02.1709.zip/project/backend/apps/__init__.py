"""
Django apps package.
"""