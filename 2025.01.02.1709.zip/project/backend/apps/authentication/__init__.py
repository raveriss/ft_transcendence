"""
Authentication app package.
"""